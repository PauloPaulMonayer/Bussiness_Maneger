﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Manager
{
    public class Roadservices : Contractors
    {
        public int AmountOfCalls { get; set; }
        public double AvgCallForDay { get; set; }
        public double CostOfCall { get; set; }

        public Roadservices(string name, int age, int experience, int phonenumber, string email, int amountOfCalls, double avgCallForDay, double costOfCall)
            : base(name, age, experience, phonenumber, email)
        {
            AmountOfCalls = amountOfCalls;
            AvgCallForDay = avgCallForDay;
            CostOfCall = costOfCall;
        }
    }
}
