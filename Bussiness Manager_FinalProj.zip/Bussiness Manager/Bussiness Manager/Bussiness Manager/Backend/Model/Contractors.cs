﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Manager
{
    public abstract class Contractors : BusinessManager
    {
        public int PhoneNumber { get; set; }
        public string Email { get; set; }

        protected Contractors(string name, int age, int experience, int phoneNumber, string email)
            : base(name, age, experience)
        {
            PhoneNumber = phoneNumber;
            Email = email;
        }
    }
}
