﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Manager
{
    [Serializable]

    public abstract class Workers : BusinessManager
    {
        public int PhoneNumber { get; set; }
        public string Email { get; set; }

        protected Workers(string name, int age, int experience, int phonenumber, string email)
        : base(name, age, experience)
        {
            PhoneNumber = phonenumber;
            Email = email;
        }


    }
}
