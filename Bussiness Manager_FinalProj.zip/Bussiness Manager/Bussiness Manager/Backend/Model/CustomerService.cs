﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Manager
{
    [Serializable]
    public class CustomerService : Workers
    {
        public int HowMuchCalls { get; set; }
        public int CallAvg { get; set; }

        public CustomerService(string name, int age, int experience, int phonenumber, string email, int howMuchCalls, int callAvg) : base(name, age, experience, phonenumber, email)
        {
            HowMuchCalls = howMuchCalls;
            CallAvg = callAvg;
        }

    }
}
