﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Manager
{
    [Serializable]

    public class SalesMen : Workers
    {
        public int HowMuchDeals { get; set; }
        public int TotalMoney { get; set; }

        public SalesMen(string name, int age, int experience, int phonenumber, string email, int howMuchDeals, int totalMoney) : base(name, age, experience, phonenumber, email)
        {
            HowMuchDeals = howMuchDeals;
            TotalMoney = totalMoney;
        }

        public SalesMen(string name, int age, int experience, int phonenumber, string email) : base(name, age, experience, phonenumber, email)
        {
        }
    }
}
